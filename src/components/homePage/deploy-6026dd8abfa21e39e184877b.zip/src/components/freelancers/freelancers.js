import React from 'react';

function freelancers() {
    // const [Freelancers , setFreelancers] = useState([
    //     { id:1 , name:"naveed" , learned : "javascript , node js , react js"},
    //     { id:2 , name:"ali" , learned : "javascript , node js , react js"}
    // ])
    return (
        <div>
            hello world
        </div>
    )
}

export default freelancers;
