import React from 'react'

function jobs() {
    return (
        <div>
            
        </div>
    )
}

export default jobs;
