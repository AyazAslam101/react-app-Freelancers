import React from 'react'
import {ArrowDownOutlined } from "@ant-design/icons";
import "./styles.css";


function animation() {

    return (
        <div className="child"  style={{textAlign: "center"}}>
        <ArrowDownOutlined  style={{fontSize : 40 , }}/>
    </div>
    )
}

export default animation
