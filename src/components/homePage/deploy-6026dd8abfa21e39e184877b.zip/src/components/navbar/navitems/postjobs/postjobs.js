import React from 'react'
import {Button} from "antd";

function postJobs() {
    return (
        <div>
            <Button type="link">Post Jobs</Button>
        </div>
    )
}

export default postJobs;
