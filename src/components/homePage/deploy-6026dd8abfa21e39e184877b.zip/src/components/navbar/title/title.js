import React from 'react'
// import {menu} from 'antd';

function title() {
    return (
        <div>
             <h2 className="title">Freelancers<span>.co</span></h2>
        </div>
    )
}

export default title
