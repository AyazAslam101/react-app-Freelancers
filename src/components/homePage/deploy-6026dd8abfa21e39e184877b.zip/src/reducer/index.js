import {userDetails  } from './user'
// import {userProfileData} from './userProfileData'
import {combineReducers} from 'redux'

const combine = combineReducers({
    userDetails,
})

export default combine;