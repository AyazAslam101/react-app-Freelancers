export const USER_ACTION = "USERS";
export const USER_PROFILE_ACTION = "USER_PROFILE"
export const PROPOSAL_ACTION = "USER_PROPOSAL"
export const JOB_ACTION = "USER_JOB"
export const CLIENT_DATA = "CLIENTS_DATA"
